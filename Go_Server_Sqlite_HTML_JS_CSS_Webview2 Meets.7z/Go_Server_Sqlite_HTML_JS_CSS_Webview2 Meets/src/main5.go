package main

import (
	"database/sql"
	"encoding/json"
	"embed"
	"io/fs"
	"log"
	"net/http"
	"time"

	"github.com/jchv/go-webview2"
	_ "github.com/mattn/go-sqlite3"
)

// Embedding static files (HTML, CSS, JS)
var (
	//go:embed static/*
	staticFiles embed.FS
)

type Record struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Value string `json:"value"`
}

// Backend server function
func startBackend() {
	// Open database connection
	db, err := sql.Open("sqlite3", "./data.db")
	if err != nil {
		log.Fatal("Error opening database:", err)
	}
	defer db.Close()

	// Ensure database is ready
	_, err = db.Exec("CREATE TABLE IF NOT EXISTS records (id INTEGER PRIMARY KEY, name TEXT, value TEXT)")
	if err != nil {
		log.Fatal("Error creating table:", err)
	}

	// Insert sample data if the table is empty
	row := db.QueryRow("SELECT COUNT(*) FROM records")
	var count int
	row.Scan(&count)

	if count == 0 {
		_, err := db.Exec("INSERT INTO records (name, value) VALUES ('Example 1', 'Value 1'), ('Example 2', 'Value 2')")
		if err != nil {
			log.Fatal("Error inserting initial data:", err)
		}
		log.Println("Inserted initial data into records table.")
	}

	// Serve static files
	staticFS, err := fs.Sub(staticFiles, "static")
	if err != nil {
		log.Fatal("Error creating static file server:", err)
	}

	http.Handle("/", http.FileServer(http.FS(staticFS)))

	// Serve the data as JSON
	http.HandleFunc("/data", func(w http.ResponseWriter, r *http.Request) {
		rows, err := db.Query("SELECT id, name, value FROM records")
		if err != nil {
			log.Println("Error querying database:", err)
			http.Error(w, "Database error", http.StatusInternalServerError)
			return
		}
		defer rows.Close()

		var records []Record
		for rows.Next() {
			var record Record
			if err := rows.Scan(&record.ID, &record.Name, &record.Value); err != nil {
				log.Println("Error scanning row:", err)
				continue
			}
			records = append(records, record)
		}

		json.NewEncoder(w).Encode(records)
	})

	log.Println("Starting backend server on :8080")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatal("Failed to start backend:", err)
	}
}

// Main function for starting both backend and WebView
func main() {
	// Start the backend server in a goroutine
	go startBackend()

	// Delay to ensure the backend starts before WebView loads
	time.Sleep(2 * time.Second)

	// Start the WebView in the main goroutine
	w := webview2.NewWithOptions(webview2.WebViewOptions{
		Debug:     true,
		AutoFocus: true,
		WindowOptions: webview2.WindowOptions{
			Title:  "WebView with Integrated Backend",
			Width:  1024,
			Height: 768,
			Center: true,
		},
	})
	if w == nil {
		log.Fatalln("Failed to load WebView.")
	}
	defer w.Destroy()

	// Navigate to the local server which serves the static files
	w.Navigate("http://localhost:8080/index.html")

	w.Run()
}
